<?php
    class User_model extends MY_Model
    {
        protected $table = 'user';
    }
?>
