<?php
    if ( ! defined('BASEPATH')) exit('No direct script access allowed');

    class News_model extends CI_Model
    {

        protected $table = 'news';

        public function ajouter_news($auteur, $titre, $contenu)
        {
            /*//Ces donnees seront automatiquement echappees
            $this->db->set('auteur', $auteur);
            $this->db->set('titre', $titre);
            $this->db->set('contenu', $contenu);

            //Ces donnees ne seront pas echappees
            $this->db->set('date_ajout', 'NOW()', false);
            $this->db->set('date_modif', 'NOW()', false);

            //On insere tout
            return $this->db->insert($this->table);*/

            return $this->db->set('auteur', $auteur)
                            ->set('titre', $titre)
                            ->set('contenu', $contenu)
                            ->set('date_ajout', 'NOW()', false)
                            ->set('date_modif', 'NOW()', false)
                            ->insert($this->table);
        }

        public function editer_news($id, $titre = null, $contenu = null)
        {
            if ($titre == null AND $contenu == null) {
                return false;
            }

            if ($titre != null) {
                $this->db->set('titre', $titre);
            }

            if ($contenu != null) {
                $this->db->set('contenu', $contenu);
            }

            //Ces donnees ne seront pas echappees
            $this->db->set('date_modif', 'NOW()', false);

            $this->db->where('id', (int) $id);

            return $this->db->update($this->table);
        }

        public function supprimer_news($id)
        {
            return $this->db->where('id', (int) $id)
                            ->delete($this->table);
        }

        public function count($where = [])
        {
            return (int) $this->db->where($where)
                                  ->count_all_results($this->table);
        }

        public function lister_news($nb = 10, $debut = 0)
        {
            return $this->db->select('*')
                            ->from($this->table)
                            ->limit($nb, $debut)
                            ->order_by('id', 'desc')
                            ->get()
                            ->result();
        }

        public function get_info()
        {
            /*return [
                'auteur' => 'ndranto',
                'date' => '28/02/2019',
                'email' => 'ndranto@test.com'
            ];*/
        }
    }
?>
