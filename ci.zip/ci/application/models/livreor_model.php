<?php
    if ( ! defined('BASEPATH')) exit('No direct script access allowed');

    class Livreor_model extends CI_Model
    {
        protected $table = 'livreor_commentaires';

        public function ajouterCommentaire($pseudo, $message)
        {
            if(!is_string($pseudo) OR !is_string($message) OR empty($pseudo) OR empty($message)) {
                return false;
            }

            /*return $this->db->set([
                                'pseudo' => $pseudo,
                                'message', $message
                            ])
                            ->set('date', 'NOW()', false)
                            ->insert($this->table);*/
            return $this->db->set('pseudo', $pseudo)
                            ->set('message', $message)
                            ->set('date', 'NOW()', false)
                            ->insert($this->table);
        }

        public function count()
        {
            return $this->db->count_all($this->table);
        }

        /*public function listerCommentaire($nb, $debut = 0)
        {
            if (!is_integer($nb) OR $nb < 1 OR is_integer($debut) OR $debut < 0) {
                return false;
            }

            return $this->db->select('`id`, `pseudo`, `message`, DATE_FORMAT(`date`, \'%d/%m/%y &agrave; %H:%i:%s\') AS \'date\'', false)
                            ->from($this->table)
                            ->limit($nb, $debut)
                            ->get()
                            ->result();
        }*/

        public function listerCommentaire()
        {

            return $this->db->select('`id`, `pseudo`, `message`, DATE_FORMAT(`date`, \'%d/%m/%y &agrave; %H:%i:%s\') AS \'date\'', false)
                ->from($this->table)
                ->order_by('id', 'asc')
                ->get()
                ->result();
        }

        public function modifierCommentaire($id, $pseudo, $message)
        {
            if (is_numeric($id) && $id != '') {
                if ($pseudo != '') {
                    $this->db->set('pseudo', $pseudo);
                }
                if ($message != '') {
                    $this->db->set('message', $message);
                }
                $this->db->set('date', 'NOW()', false);

                $this->db->where('id', (int) $id);
                return $this->db->update($this->table);
            }

        }

        public function supprimerCommentaire($id)
        {
            $this->db->where('id', (int) $id)
                     ->delete($this->table);
        }

        public function avoirUnCommentaire($id)
        {
            $post = $this->db->select('`id`, `pseudo`, `message`, `date`')
                             ->from($this->table)
                             ->where('id', (int) $id)
                             ->get()
                             ->result();
            return $post;
        }
    }
?>
