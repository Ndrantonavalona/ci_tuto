<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Missions_model extends CI_Model
{
    protected $table = 'missions';

    public function listerMissions()
    {
        return  $this->db->select('`id`, `nom`, `typeMission`', false)
                ->from($this->table)
                ->order_by('id', 'asc')
                ->get()
                ->result();
    }

    public function ajouterMission($nom)
    {
        if(!is_string($nom) OR empty($nom)) {
            return false;
        }
        return  $this->db->set('nom', $nom)
                ->insert($this->table);
    }

    public function modifierMission($id, $nom)
    {
        if (is_numeric($id) && $id != '') {
            if ($nom != '') {
                $this->db->set('nom', $nom);
            }

            $this->db->where('id', (int)$id);
            return $this->db->update($this->table);
        }
    }

    public function supprimerMission($id)
    {
        $this->db->where('id', (int) $id)
        ->delete($this->table);
    }
}
?>
