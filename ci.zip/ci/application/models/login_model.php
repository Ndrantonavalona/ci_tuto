<?php
    if (!defined('BASEPATH')) exit('No direct script access allowed');
    class Login_model extends CI_Model
    {
        protected $table = 'users';
        public function getLogin ($login, $pwd)
        {
            if ($login != '' && $pwd != '') {
                $post = $this->db->where('login', trim($login))
                    ->where('password', trim($pwd))
                    ->from($this->table)
                    ->get();
                    //->result();
                if ($post->num_rows() == 1) {
                    //return $post->result();
                    return $post->row(0)->id;
                } else {
                    return false;
                }
            }
        }
    }
?>
