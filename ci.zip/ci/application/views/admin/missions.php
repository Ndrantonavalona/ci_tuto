<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?php echo css_url('bootstrap/css/bootstrap'); ?>">
    <link rel="stylesheet" href="<?php echo css_url('style'); ?>?v=1.1">
    <title>Accueil</title>
</head>
<body>
    <header>
        <ul class="ul-disp-block">
            <li class="header-li-start"><a href="#" class="color-wh">Configuration</a></li>
            <li><a href="#" class="color-wh">Mouvement</a></li>
            <li><a href="#" class="color-wh">Journal</a></li>
            <li><a href="#" class="color-wh">Tableau de bord</a></li>
            <li><a href="#" class="color-wh">Discuter</a></li>
            <li><a href="#" class="color-wh">Calendrier</a></li>
            <li class="header-li-last" class="color-wh"><a href="#" class="color-wh"><i class="glyphicon glyphicon-log-out"></i> Se deconnecter</a></li>
        </ul>
        <div class="">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb bread-bgk">
                    <li class="breadcrumb-item  bread-principal">Missions</li>
                    <li class="breadcrumb-item active" aria-current="page">Type de mission</li>
                </ol>
                <div class="pad-left-15">
                    <button class="txt-upper bg-button color-wh no-bord btn-save" id="btn_add_mission" data-sauvegarder="Sauvegarder" data-creer="Cr&eacute;er / Modifier">Cr&eacute;er / Modifier</button>
                    <button class="add-cancel txt-upper hide" id="btn_cancel">Annuler</button>
                </div>
            </nav>
        </div>
    </header>
    <section class="main">
        <div class="pad-left-55">
            <h1>Type de mission</h1>
            <ul class="pad-left-10 mrg-top-25">
                <li class="th-upper">Type de mission</li>
                <li class="th-upper pad-left-15">Poste</li>
                <li class="th-upper pad-left-15">Missionnaire</li>
            </ul>
            <hr class="mrg-top-5">
            <a class="hide" id="toHome" href="<?php echo site_url(['missions', 'index'])?>"></a>
            <table id="tableList">
                <tbody>
                    <?php foreach($missions as $mission):; ?>
                        <tr class="tr-tbl-list" id="list_<?php echo $mission->id; ?>">
                            <!--<td><input type="text" name="mission" class="input-mission" value="<?php echo strtoupper($mission->nom); ?>"></td>-->
                            <form action="" method="post">
                                <td class="td-mission" id="mission_<?php echo $mission->id; ?>"><span id="span_<?php echo $mission->id; ?>"><?php echo strtoupper($mission->nom); ?></span></td>
                                <input type="hidden" id="inpMission" value="">
                            </form>
                            <!--<td class="td-mission"><input type="text" name="mission" class="input-mission" value="<?php echo strtoupper($mission->nom); ?>"></td>-->
                            <!--<td class="td-edit opacity-0" id="edit_mission_<?php echo $mission->id; ?>"><a class="color-black" href="<?php echo site_url(['missions', 'modifierMission', $mission->id ]); ?>"><i class="glyphicon glyphicon-edit"></i></a></td>-->
                            <td class="td-edit opacity-0" id="edit_mission_<?php echo $mission->id; ?>"><i class="glyphicon glyphicon-edit"></i></td>
                            <td class="td-wd-10"></td>
                            <!--<td class="td-delete opacity-0" id="delete_mission_<?php echo $mission->id; ?>"><a class="color-black" href="<?php echo site_url(['missions', 'supprimerMission', $mission->id ]); ?>"><i class="glyphicon glyphicon-trash"></i></a></td>-->
                            <td class="td-delete opacity-0" id="delete_mission_<?php echo $mission->id; ?>"><i class="glyphicon glyphicon-trash"></i></td>
                        </tr>
                    <?php endforeach; ?>
                    <input type="hidden" id="idMission" value="">
                </tbody>
                <tfoot>
                    <tr class="tr-add hide" id="ajout_mission">
                        <td class="color-green" id="addMission"><strong><a href="" class="color-green-a">Ajouter un &eacute;l&eacute;ment</a></strong></td>
                    </tr>
                </tfoot>
            </table>
        </div>
    </section>
    <aside class="bg-aside">
        <div class="bg-color-aside">
            <ul>
                <li>Mission</li>
                <li>Transport</li>
                <li>Mat&eacute;riels consommables</li>
                <li>Situation géographique</li>
                <li>Collecte</li>
            </ul>
        </div>
    </aside>

    <script src="<?php echo javascript_url('jquery-3.1.0.min'); ?>"></script>
    <script src="<?php echo javascript_url('mission'); ?>"></script>
</body>
</html>
