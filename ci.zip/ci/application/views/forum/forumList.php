<h1>Bonjour</h1>
<p>Page de test d'affichage d'une vue</p>
<ul>
    <li>Votre pseudo : <?php echo $pseudo ?></li>
    <li>Votre email : <?php echo $email ?></li>
    <li>Votre tel : <?php echo $tel ?></li>
    <li>
        <?php
            if ($actif) {
                echo 'Vous etes actif';
            } else {
                echo 'Vous etes inactif';
            }
        ?>
    </li>
</ul>
