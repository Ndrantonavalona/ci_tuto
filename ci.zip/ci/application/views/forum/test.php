<h1>Test</h1>
<p>Auteur : <?php echo $user_info; ?></p>
<p>
    <!--<a href="<?php echo site_url(); ?>">Accueil</a>
    <a href="<?php echo site_url('test'); ?>">Accueil du test</a>
    <a href="<?php echo site_url(['test', 'accueil']); ?>">Accueil du test</a>
    <a href="<?php echo site_url('test/secret'); ?>">Page secrete</a>
    <a href="<?php echo site_url(['test', 'secret']); ?>">Page secrete</a>-->
</p>
