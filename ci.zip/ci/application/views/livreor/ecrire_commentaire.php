<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Ajout livre d'or</title>
    <link rel="stylesheet" href="<?php echo css_url('livreor/style'); ?>">
</head>
<body>
    <?php if (isset($posts)): ?>
        <?php foreach ($posts as $post): ?>
            <?php
            $pseudonyme = $post->pseudo;
            $content = $post->message;
            $id = $post->id;
            ?>
        <?php endforeach; ?>
    <?php endif; ?>
    <form action="<?php echo (isset($id)) ? site_url(['livreOr', 'modifierCommentaire', $id]) : ''; ?>" method="post">
        <div>
            <label for="pseudo">Pseudo : </label>
            <input type="text" name="pseudo" value="<?php echo (!isset($id)) ? set_value('pseudo') : $pseudonyme; ?>">
            <?php
                if (!isset($id)) {
                    echo form_error('pseudo');
                }
            ?>
        </div>
        <div>
            <label for="pseudo">Contenu : </label>
            <textarea name="contenu"><?php echo (!isset($id)) ? set_value('contenu') : $content; ?></textarea>
            <?php
                if (!isset($id)) {
                    echo form_error('contenu');
                }
            ?>
        </div>
        <p>
            <input type="submit" value="Valider votre commentaire" />
        </p>
    </form>
</body>
</html>
