<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Ajout livre d'or</title>
    <link rel="stylesheet" href="<?php echo css_url('livreor/style'); ?>">
</head>
<body>
<form action="" method="post">
    <div id="confirmation">
        <?php if (isset($posts)) : ?>
            <?php foreach ($posts as $post) : ?>
                <?php
                    $id = $post->id;
                ?>
            <?php endforeach; ?>
        <?php endif; ?>
        <p><?php echo (!isset($id)) ? 'Ajout' : 'Modification'; ?> effectué<?php echo (!isset($id)) ? '' : 'e'; ?> avec succès</p>
        <a href="<?php echo site_url('livreOr'); ?>">Revenir à la liste des commentaires</a>
    </div>
</form>
</body>
</html>
