<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Un livre d'or avec CodeIgniter</title>
    <link rel="stylesheet" href="<?php echo css_url('livreor/style')?>">
</head>
<body>
    <div id="messages">
        <p>
            Il y a actuellement <?php echo $nb_commentaires; ?> <br />
            <a href="<?php echo site_url(['livreOr', 'ecrire']); ?>">Ecrire un commentaire</a>
        </p>

        <!--<div class="pagination"><?php echo $pagination; ?></div>-->

        <?php foreach ($messages as $message) : ?>
            <div id="num_<?php echo $message->id; ?>" class="message">
                <p>
                    <a href="#num_<?php echo $message->id; ?>"><?php echo $message->id; ?></a>
                    Par <span class="pseudo_commentaire"><?php echo htmlentities($message->pseudo); ?></span>
                    Le <span class="date_commentaire"><?php echo $message->date; ?></span>
                    <input type="hidden" name="id" value="<?php echo $message->id; ?>">
                    <a href="<?php echo site_url(['livreOr', 'supprimer', $message->id ]); ?>"><span style="float: right;">Supprimer</span></a>
                    <a href="<?php echo site_url(['livreOr', 'detailCommentaire', $message->id ]); ?>"><span>Modifier</span></a>
                </p>
                <div class="contenu_commentaire">
                    <?php echo nl2br(htmlentities($message->message)); ?>
                </div>
            </div>
        <?php endforeach; ?>

        <!--<div class="pagination"><?php echo $pagination; ?></div>-->
    </div>
</body>
</html>
