<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Login</title>
    <link rel="stylesheet" href="<?php echo css_url('bootstrap/css/bootstrap'); ?>">
</head>
<body>
    <div class="container" style="margin-top: 5%;">
        <div class="row">
            <form action="<?php echo site_url(['login', 'formLogin']); ?>" method="post">
                <?php if ($this->session->flashdata('login_failed')) :?>
                    <p class="alert alert-danger dismissable"><?php echo $this->session->flashdata('login_failed'); ?></p>
                <?php endif; ?>
                <div class="form-group">
                    <label for="login">Login : </label>
                    <input type="text" class="form-control" name="login" placeholder="Login" value="<?php echo isset($_POST['login']) ? $_POST['login'] : set_value('logn')?>"/>
                    <?php echo form_error('login')?>
                </div>
                <div class="form-group">
                    <label for="login">Mot de passe : </label>
                    <input type="password" class="form-control" name="password" placeholder="Mot de passe" value="<?php echo isset($_POST['password']) ? $_POST['password'] : set_value('password'); ?>"/>
                    <?php echo form_error('password')?>
                </div>
                <div class="form-group">
                    <button type="submit" class="btn btn-primary"><i class="glyphicon glyphicon-user"></i> Se connecter</button>
                </div>
            </form>
        </div>
    </div>
</body>
</html>
