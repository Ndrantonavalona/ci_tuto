<?php
    if (!defined('BASEPATH')) exit('No direct script access allowed');

    class LivreOr extends CI_Controller
    {
        public function __construct()
        {
            parent::__construct();

            //Chargement des resources pour tous les controleurs
            $this->load->database();
            $this->load->helper(['url', 'assets_helper']);
            $this->load->model('livreor_model', 'livreOrManager');
        }

        public function index($nb_com = 1)
        {
            $this->voir($nb_com);
        }

        public function voir($nb_com = 1)
        {
            $this->load->library('pagination');

            $data = [];

            //Recuperation du count des messages sauvegardés
            $nb_com_total = $this->livreOrManager->count();

            if ($nb_com > 1) {
                if ($nb_com <= $nb_com_total) {
                    $new_nb_com = intval($nb_com);
                } else {
                    $new_nb_com = 1;
                }
            } else {
                $new_nb_com = 1;
            }

            /*//Pagination
            $this->pagination->initialize([
                'base_url' => base_url() . 'index.php/livreOr/voir/',
                'total_rows' => $nb_com_total,
                'per_page' => self::NB_COMMENTAIRE_PAR_PAGE
            ]);

            $data['pagination'] = $this->pagination->create_links();*/

            $data['nb_commentaires'] = $nb_com_total;

            //$data['messages'] = $this->livreOrManager->listerCommentaire(self::NB_COMMENTAIRE_PAR_PAGE, $new_nb_com - 1);
            $data['messages'] = $this->livreOrManager->listerCommentaire();
            $this->load->view('livreor/afficher_commentaires', $data);
        }

        public function ecrire()
        {
            $this->load->library('form_validation');
            $this->form_validation->set_error_delimiters('<p class="form_erreur"></p>');

            $this->form_validation->set_rules('pseudo', '"Votre pseudo"', 'trim|required|min_length[3]|max_length[60]|alpha_dash');
            $this->form_validation->set_rules('contenu', '"Le contenu"', 'trim|required|min_length[3]|max_length[600]');

            if ($this->form_validation->run()) {
                $post_pseudo = $this->input->post('pseudo');
                $post_contenu = $this->input->post('contenu');
                $this->livreOrManager->ajouterCommentaire($post_pseudo, $post_contenu);

                //Affichage de la confirmation
                $this->load->view('livreor/confirmation');
            } else {
                $this->load->view('livreor/ecrire_commentaire');
            }
        }

        public function detailCommentaire($id)
        {
            //$this->load->view('livreor/ecrire_commentaire', $data);
            $post['posts'] = $this->livreOrManager->avoirUnCommentaire($id);
            $this->load->view('livreor/ecrire_commentaire', $post);
        }

        public function modifierCommentaire($id)
        {
            $pseudoUpd = $this->input->post('pseudo');
            $messageUpd = $this->input->post('contenu');
            $this->livreOrManager->modifierCommentaire($id, $pseudoUpd, $messageUpd);
            $post['posts'] = $this->livreOrManager->avoirUnCommentaire($id);
            $this->load->view('livreor/confirmation', $post);
        }

        public function supprimer($id)
        {
            $this->livreOrManager->supprimerCommentaire($id);
            $this->voir();
        }
    }
?>
