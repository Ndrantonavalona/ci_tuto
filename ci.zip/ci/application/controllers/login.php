<?php
    class Login extends CI_Controller
    {
        public function __construct()
        {
            parent::__construct();
            $this->load->helper(['url', 'assets_helper']);
            $this->load->database();
            $this->load->model('login_model', 'loginModel');
            $this->load->library('form_validation');
            $this->load->library('session');
        }

        public function index()
        {
            /*if ($this->session->userdata()) {
                $this->load->view('home/home');
            } else {
                $this->load->view('login/index');
            }*/
            $this->load->view('login/index');
        }
        public function home()
        {
            $this->load->view('home/home');
            /*if ($this->session->userdata('user_id') != '') {
                //$this->load->view('home/home');
                redirect('home/home');
            } else {
                //$this->load->view('login/index');
                redirect('login/index');
            }*/
        }
        public function formLogin()
        {
            $this->form_validation->set_error_delimiters('<p class="error"></p>');
            $this->form_validation->set_rules('login', 'login', 'trim|required|min_length[4]|alpha_dash');
            $this->form_validation->set_rules('password', 'password', 'trim|required|min_length[4]|alpha_dash');
            if ($this->form_validation->run()) {
                $login = $this->input->post('login');
                $pwd = $this->input->post('password');
                $user_id = $this->loginModel->getLogin($login, $pwd);
                if ($user_id) {
                    $user_data = [
                        'user_id' => $user_id,
                        'username' => $login,
                        'logged_in' => true
                    ];
                    $this->session->set_userdata($user_data);
                    $this->session->set_flashdata('login_success', 'Vous êtes connectés');
                    $this->load->view('home/home');
                } else {
                    $this->session->set_flashdata('login_failed', 'Invalide login et ou mot de passe');
                    $this->load->view('login/index');
                }
            } else {
                $this->load->view('login/index');
            }
        }

        public  function formLogout()
        {
            $this->session->unset_userdata('user_id');
            $this->session->unset_userdata('username');
            $this->session->unset_userdata('logged_in');
            $this->session->sess_destroy();

            $this->load->view('login/index');
        }
    }
?>
