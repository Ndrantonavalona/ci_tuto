<?php
    class Forum extends CI_Controller
    {

        private $titre_default;

        /*public function __construct()
        {
            parent::__construct();
            $this->titre_default = 'Mon super site';
            echo 'Bonjour';
        }*/

        public function index()
        {
            //echo 'index';
            $this->accueil();
        }

        public function maintenance()
        {
            echo 'C\'est une page de maintenance';
        }

        /*public function _remap($method)
        {
            $this->maintenance();
        }*/

        public function accueil()
        {
            $data = [];
            $data['pseudo'] = 'ndranto';
            $data['email'] = 'eddy.ndranto@test.com';
            $data['actif'] = false;
            $data['tel'] = 12345;
            $this->load->view('forum/forumList', $data, false);
        }

        public function bonjour ($pseudo = '')
        {
            echo 'Salut : ' . $pseudo;
        }

        public function manger($plat = '', $boisson = '')
        {
            echo 'Votre plat : ' . $plat . '<br />';
            echo 'Votre boisson : ' . $boisson;
        }
    }
?>
