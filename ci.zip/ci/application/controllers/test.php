<?php
    class Test extends CI_Controller
    {

        public function __construct()
        {
            parent::__construct();
            $this->load->helper('url');

        }

        public function count($champ = [], $valeur = null)
        {
            return (int) $this->db->where($champ, $valeur)
                                  ->from($this->table)
                                  ->count_all_results();
        }

        public function create($option_echappe = [], $option_non_echappee = [])
        {
            //Verification des donnees a inserer
            if (empty($option_echappe) AND empty($option_non_echappee)) {
                return false;
            }

            return (bool) $this->db->set($option_echappe)
                                   ->set($option_non_echappee, null, false)
                                   ->insert($this->table);

        }

        public function accueil()
        {
            $this->load->model('user_model', 'userManager');
            // Le nombre d'entrées dans la table du modèle userManager
                        $nb_membres = $this->userManager->count();
            // Une seule condition
                        $nb_messages = $this->userManager->count('pseudo', 'Arthur');
            // Multiples conditions
            $option = array();
            $option['titre'] = 'Mon Super Titre';
            $option['auteur'] = 'Arthur';
            $nb_messages_deux = $this->userManager->count($option);
        }
        public function index()
        {
            //$this->output->enable_profiler(true);
            //Premiere requete
            $this->benchmark->mark('requete1_start');
            $query = $this->db->query('SELECT `*` FROM `news`')->result();
            $this->benchmark->mark('requete1_end');

            //Deuxieme requete
            $this->benchmark->mark('requete2_start');
            $query = $this->db->select('*')
                              ->from('news')
                              ->get()
                              ->result();
            $this->benchmark->mark('requete2_end');

            //$this->output->enable_profiler(true);
            echo $this->benchmark->elapsed_time('requete1_start', 'requete1_end');
        }

    }
?>
