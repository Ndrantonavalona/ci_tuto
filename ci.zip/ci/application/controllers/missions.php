<?php
    if (!defined('BASEPATH')) exit('No direct script access allowed');

    class Missions extends CI_Controller
    {
        public function __construct()
        {
            parent::__construct();
            //$this->load->database();
            $this->load->helper(['url', 'assets_helper']);
            $this->load->model('missions_model', 'missionModel');
        }

        public function index()
        {
            //$this->load->view('admin/default');
            $this->listerMissions();
        }

        public function listerMissions()
        {
            $data = [];
            $data['missions'] = $this->missionModel->listerMissions();
            $this->load->view('admin/missions', $data);
        }

        public function ajouterMission()
        {
            $mission = $this->input->post('mission');
            $this->missionModel->ajouterMission($mission);

            //Affichage de la confirmation
            $this->load->view('admin/missions');
        }

        public function modifierMission($id)
        {
            $nom = $this->input->post('nom');
            $this->missionModel->modifierMission($id, $nom);
            //$this->load->view('livreor/confirmation', $post);
            $this->load->view('admin/missions');
        }

        public function supprimerMission($id)
        {
            $this->missionModel->supprimerMission($id);
            $this->index();
        }
    }
?>
