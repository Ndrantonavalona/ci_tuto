<?php
    class testLayout extends CI_Controller
    {
        public function index()
        {
            $this->load->library('layout');

            $this->layout->views('layout/premiere_vue')
                         ->views('layout/deuxieme_vue')
                         ->views('layout/troisieme_vue');

        }
    }
?>
