<?php
    if(!defined('BASEPATH')) exit('No direct script access allowed');

    class usersCtrl extends CI_Controller
    {
        function index()
        {
            $this->load->view('angular/index');
        }
        public function getAllUsers()
        {
            $this->load->database();
            $test = $this->db->select('*')
                         ->from('livreor_commentaires')
                         ->get()
                         ->result();

            echo json_encode($test);
        }
    }
?>
