<?php
    if ( ! defined('BASEPATH')) exit('No direct script access allowed');

    if ( ! function_exists('css_url')) {
        function css_url($name)
        {
            return base_url() . 'assets/css/' . trim($name) . '.css';
        }
    }

    if ( ! function_exists('javascript_url')) {
        function javascript_url($name)
        {
            return base_url() . 'assets/js/' . trim($name) . '.js';
        }
    }

    if ( ! function_exists('image_url')) {
        function image_url($name)
        {
            return base_url() . 'assets/img/' . trim($name);
        }
    }

    if ( ! function_exists('img')) {
        function img($name, $alt)
        {
            return '<img src="' .image_url($name). '"alt="' . $alt .'">';
        }
    }

?>
