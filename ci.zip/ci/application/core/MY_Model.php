<?php if ( ! defined('BASEPATH')) exit('No direct script access
allowed');
// -----------------------------------------------------------------------------
class MY_Model extends CI_Model
{
    /**
     * Insère une nouvelle ligne dans la base de données.
     */
    public function create()
    {
    }
    /**
        * Récupère des données dans la base de données.
    */
    public function read()
    {
    }
    /**Modifie une ou plusieurs lignes dans la base de données.*/
    public function update()
    {
    }
    /**
        * Supprime une ou plusieurs lignes de la base de données.
     */
    public function delete()
    {
    }
    /**
        * Retourne le nombre de résultats.
    */
    public function count()
    {
    }
}
