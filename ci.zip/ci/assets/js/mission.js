$(document).ready(function () {
    var $href = $('#toHome').attr('href');

    $("[id^='btn_']").click(function(e){
        var $attr = $(this).attr('id').split('_'),
            $this = $(this);
        if ($attr[1] == 'add') {
            if ($this.text() == $this.data('sauvegarder')) {
                $this.text($this.data('creer'));
                $('#btn_cancel').addClass('hide');
                if($this.hasClass('btn-add')){
                    if ($('tableList').find('tbody').find('input').val('')) {
                        //
                        var $idMission = $('#idMission').val();
                        $.ajax({type : "POST",
                            url : "modifierMission/" + $idMission,
                            data :
                            {
                                nom : $('#nom').val()
                            },
                            dataType: "html",
                            success : function(response){
                                window.location.href = $href;
                            }
                        });
                    } else {
                        console.log('nothing');
                    }
                } else {
                    //('tableList').find('tbody').find('input').val('');
                    if ($('tableList').find('tbody').find('input').val('')) {
                        //
                        var $val = $('tableList').find('tbody').find('input').val('');
                        $('#inpMission').val($('#mission').val());
                        $.ajax({type : "POST",
                            url : "ajouterMission",
                            data :
                                {
                                    mission : $('#mission').val()
                                },
                            dataType: "html",
                            success : function(response){
                                window.location.href = $href;
                            }
                        });
                    } else {
                        console.log('nothing');
                    }
                }
            } else {
                $this.text($this.data('sauvegarder'));
                $("[id^='edit_mission_'], [id^='delete_mission_']").removeClass('opacity-0');
                $('#btn_cancel').removeClass('hide');
                $('#ajout_mission').removeClass('hide');
            }
        } else {
            $('#btn_cancel').addClass('hide');
            $("[id^='btn_add_']").text($("[id^='btn_add_']").data('creer'));
            $("[id^='edit_mission_'], [id^='delete_mission_']").addClass('opacity-0');
            $('#ajout_mission').addClass('hide');
            window.location.href = $href;
        }
    });
    $('[id^="delete_mission_"]').click( function () {
        var $attr = $(this).attr('id').split('_')[2];
        $.ajax({type : "GET",
            url : "supprimerMission/" + $attr,
            dataType: "html",
            success : function(response){
                window.location.href = $href;
            }
        });
    });
    $('[id^="edit_mission_"]').click( function () {
        var $attr = $(this).attr('id').split('_')[2];

        $('#mission_' + $attr).append('<input type="text" id="nom" name="nom" value="">');
        $('#span_'+ $attr).remove();

        $('#btn_add_mission').addClass('btn-add');
        $('#idMission').val($attr);
        /*$.ajax({
            type : "POST",
            url : "modifierMission/" + $attr,
            data :
            {
                nom : $('#nom').val()
            },
            dataType: "html",
            success : function(response){
                window.location.href = $href;
            }
        });*/
    });
    $('#addMission').click(function (e) {
        e.preventDefault();
        $('#tableList>tbody').append('<tr class="tr-tbl-list"><td class="td-mission"><input type="text" id="mission" name="mission" value=""></td></tr>');
    });
});
